# Classroom Electricity Waste Tracker Using Python

## 1. Introduction
Electricity can be wasted in college classrooms when lights and fans are left switched on while rooms are not in use. A simple reporting program can help students and staff record such incidents and review the number of reports.

## 2. Problem Statement
In colleges, electricity is often wasted when classroom lights and fans are left switched on even when classrooms are empty. This increases electricity consumption and unnecessary expenses. The proposed Classroom Electricity Waste Tracker is a simple Python program that allows users to report electricity wastage in classrooms. It stores classroom information during program execution, displays submitted reports and calculates the total number of reported incidents. The objective is to encourage responsible electricity usage.

## 3. Objectives
- Record electricity-wastage reports.
- Store classroom, appliance and reporter details during program execution.
- Display all submitted reports.
- Count reports for fans, lights and other appliances.
- Promote awareness about electricity conservation.

## 4. Subproblem 1 – Electricity Wastage Reporting
4.1 Ask the user to enter the classroom number.  
4.2 Ask the user to enter the appliance type: fan, light or other.  
4.3 Ask for the reporter's name.  
4.4 Store the information in three Python lists.

## 5. Subproblem 2 – Report Management
5.1 Display all submitted reports with their report number.  
5.2 Display the classroom, appliance and reporter details.  
5.3 Display a message if no reports have been submitted.

## 6. Subproblem 3 – Electricity Wastage Analysis
6.1 Count the total number of reports.  
6.2 Count fan, light and other-appliance reports.  
6.3 Compare the number of fan and light reports.  
6.4 Display which of these appliance types has more reports, or state that the counts are equal.

## 7. Implementation
The project is developed in Python using variables, strings, input/output, operators, if-else statements, loops, lists and functions. The program has three main functions: `add_report()`, `view_reports()` and `show_summary()`. The `main()` function displays the menu and calls the selected function.

## 8. Testing and Limitation
Test the program by submitting multiple reports, viewing the reports, checking the summary and entering an invalid menu choice. The current beginner version stores information in lists only while the program is running. All reports are cleared when the program closes. Permanent storage can be added later if file handling is taught.

## 9. GitHub Repository
Repository URL: **Add your actual GitHub repository URL here after uploading `main.py` and `README.md`.**

All program code is provided in `.py` format. No Jupyter Notebook files are used.
