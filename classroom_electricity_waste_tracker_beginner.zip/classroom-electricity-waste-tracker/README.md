# Classroom Electricity Waste Tracker

## Project Description
A beginner-level Python program that records reports of electricity wastage in college classrooms. Users can enter a classroom number, appliance and reporter name, view submitted reports and see a simple summary.

## Problem
Lights and fans may be left switched on in empty classrooms. This program provides a simple way for students or staff to report these incidents and review the reports.

## Features
1. Submit an electricity-wastage report.
2. View all reports submitted during the current run.
3. Count reports for fans, lights and other appliances.
4. Display which of fans or lights has more reports.

## Python Topics Used
- Variables and data types
- Input and output
- Operators
- If-else statements
- Loops
- Lists
- Strings
- Functions
- Code tracing and debugging

## How to Run
1. Install Python.
2. Download this repository.
3. Open a terminal in the project folder.
4. Run:

   `python main.py`

## Important Limitation
This beginner version stores reports in Python lists while the program is running. The reports are cleared when the program is closed. Saving reports permanently would require file handling, which is outside the topics currently covered in the course.

## Project File
- `main.py` - Complete Python source code.

## GitHub Repository
After creating your GitHub repository, add its actual URL here.
